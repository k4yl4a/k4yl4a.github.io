//UPLOADED IMAGES
let screensaver;
let keyclick;
let screen3;
let tvoff;
function preload(){
  screensaver=loadImage('tree-6883940_1280.jpg')
  keyclick =loadSound('keyboard-typing-one-short-1-292590.mp3')
  screen3 = loadImage('Screenshot 2025-03-10 at 12.30.30 PM.png')
  tvoff = loadSound("TV Turn Off Preview.mp3")
}

//SCENE AND MOVEMENT AND SOUND START
let scene = 0
let TmovementStarted = false; 
let UmovementStarted = false;
let RmovementStarted = false;
let NmovementStarted = false;
let HmovementStarted = false; 
let EmovementStarted = false;
let VmovementStarted = false;
let OmovementStarted = false;
let F1movementStarted = false;
let F2movementStarted = false;
let soundPlayed = false; 

//start rect
let rectX = 400
let rectY = 200
let rectW = 200
let rectH = 50

//start rect colors to change
let r= 117
let g= 117
let b= 108
let colspeed= 1
let r2 =0
let b2 =25
let g2 =210
    
//keys positioning
let keystartX1 = 30
let keystartX2 = 60
let keystartX3 = 90
let keyline1 = 200
let keyline2 = 275
let keyline3 =350
let keyspace = 75

//letterline positioning
let lline = 130
let xline = 50
let sline = 45
let xline2 = xline + 40

// T key animation vars
let kSpeed = 1
let TXpos1 = keystartX1 + keyspace*4
let TXpos2 = keystartX1 + keyspace*4
let TXpos3 = keystartX1 + keyspace*4
let TYpos1 = keyline1
let TYpos2 = keyline1
let TYpos3 = keyline1
let TkeysizeW = 65
let TkeysizeH = 65
let ktSpeed = 1

//U key animation vars
let UXpos = keystartX1 + keyspace*6
let UYpos = keyline1
let UkeysizeW = 65
let UkeysizeH = 65
let uSpeed = 1
let kuSpeed = 1

//R key animation vars
let RXpos = keystartX1 + keyspace*3
let RYpos = keyline1
let RkeysizeW = 65
let RkeysizeH = 65
let rSpeed = 1
let krSpeed = 1

//N key animation vars
let NXpos = keystartX3 + keyspace*5
let NYpos = keyline3
let NkeysizeW = 65
let NkeysizeH = 65
let nSpeed = 1
let knSpeed = 1

//H key animation vars
let HXpos = keystartX2 + keyspace*5
let HYpos = keyline2
let HkeysizeW = 65
let HkeysizeH = 65
let hSpeed = 1
let khSpeed = 1

//E key animation vars
let EXpos = keystartX1 + keyspace*2
let EYpos = keyline1
let EkeysizeW = 65
let EkeysizeH = 65
let eSpeed = 1
let keSpeed = 1

//V key animation vars
let VXpos = keystartX3 + keyspace*3
let VYpos = keyline3
let VkeysizeW = 65
let VkeysizeH = 65
let vSpeed = 1
let kvSpeed = 1

//O key animation vars
let OXpos = keystartX1 + keyspace*8
let OYpos = keyline1
let OkeysizeW = 65
let OkeysizeH = 65
let oSpeed = 1
let koSpeed = 1

//F1 key animation vars
let F1Xpos = keystartX2 + keyspace*3
let F1Ypos = keyline2
let F1keysizeW = 65
let F1keysizeH = 65
let f1Speed = 1

//F2 key animation vars
let F2Xpos = keystartX2 + keyspace*3
let F2Ypos = keyline2
let F2keysizeW = 65
let F2keysizeH = 65
let f2Speed = 1
let kfSpeed=1

//key size
let keysizeW = 65
let keysizeH = 65

//3 image click off
let imageW = 800
let imageH = 500
let imageWspeed = 1
let imageHspeed = 1

//Scene 3 vars
let inc =0
let dec = 500
let Ydec=500
let incspeed = 1
let decspeed = 1
let shrinkWspeed =1
let shrinkHspeed =1
let shrinkspeed = 1
let shrinkW = 800
let shrinkH =20
let shrinksize= 60
let Xinc = 0

function setup() {
  createCanvas(800, 500);
  if (scene == 3){
    tvoff.play();
  }
}

function draw() {
  
  
  
switch (scene){
//SCENE ONE - this screen lets users know they are about to play a "game" they will click on the "PLAY" button to bring them to the next scene
  case 0:
 //IMAGE BACKGROUND
    image(screensaver,0,0,800,500)
 //CLICK TO PLAY 'BUTTON'
    push();
    stroke(2)
    rect(rectX, rectY, rectW, rectH, 20)
    pop();
 //hover over "PLAY" to change color   
if(mouseX > rectX && mouseX < rectX + rectW && mouseY > rectY && mouseY < rectY + rectH){
    fill(r2,b2,g2)
  }

else{
    fill(r,g,b)
  }
    r += colspeed
    if(r < r2 ){
      colspeed *= -1
    }
    g += colspeed
    if (g > g2){
      colspeed *= -1
    }
    b += colspeed
    if( b< b2){
      colspeed *= -1
    }
//TEXT "PLAY"
    push();
    fill(225)
    textFont('CourierNew')
    textSize(50)
    text('PLAY', rectX+40, rectY+40)
    pop();
    break;
    
    
    
//SCENE TWO - brings users to a keyboard display with letter lines above , indicating there is a message to guess to spell out. I animated the right letters to help users know what to type
    case 1:
    clear();
    background(117,117,108)
//LETTER LINES
    line(xline, lline, xline2, lline) //T
    line(xline + sline, lline, xline2 + sline, lline) //U
    line(xline + sline*2, lline, xline2 +sline*2, lline) //R
    line(xline + sline*3, lline, xline2+sline*3, lline) //N
    //space
    line(xline + sline*5, lline, xline2 + sline*5, lline) //T
    line(xline + sline*6, lline, xline2 + sline*6, lline) //H
    line(xline + sline*7, lline, xline2 + sline*7, lline) //E
    //space
    line(xline + sline * 9, lline, xline2 + sline * 9, lline) //T
    line(xline + sline *10, lline, xline2 + sline *10, lline) //V
    //space
    line(xline + sline * 12, lline, xline2 + sline * 12, lline) //O
    line(xline + sline *13, lline, xline2 + sline * 13, lline) //F
    line(xline + sline * 14, lline, xline2 + sline * 14, lline) //F

//KEYBOARD BACK
    push();
    fill(0, 25, 210)
    noStroke();
    rect (10, 150, 780, 340, 30)
    pop();
//KEYBOARD KEYS
    keys(keystartX1, keyline1, keysizeW, keysizeH, 'Q');
    keys(keystartX1 + keyspace , keyline1, keysizeW, keysizeH,'W');
    keys(keystartX1 + keyspace*2, keyline1, EkeysizeW, EkeysizeH, 'E');
    keys(keystartX1 + keyspace*3, keyline1, RkeysizeW, RkeysizeH, 'R');
    keys(keystartX1 + keyspace*4, keyline1, TkeysizeW, TkeysizeH, 'T');
    keys(keystartX1 + keyspace*5, keyline1, keysizeW, keysizeH, 'Y');
    keys(keystartX1 + keyspace*6, keyline1, UkeysizeW, UkeysizeH, 'U');
    keys(keystartX1 + keyspace*7, keyline1, keysizeW, keysizeH, 'I');
    keys(keystartX1 + keyspace*8, keyline1, OkeysizeW, OkeysizeH, 'O');
    keys(keystartX1 + keyspace*9, keyline1, keysizeW, keysizeH, 'P');
    
    keys(keystartX2, keyline2, keysizeW, keysizeH, 'A');
    keys(keystartX2 + keyspace, keyline2,  keysizeW, keysizeH,'S');
    keys(keystartX2 + keyspace*2, keyline2,  keysizeW, keysizeH,'D');
    keys(keystartX2 + keyspace*3, keyline2, F1keysizeW, F1keysizeH, 'F');
    keys(keystartX2 + keyspace*4, keyline2, keysizeW, keysizeH, 'G');
    keys(keystartX2 + keyspace*5, keyline2, HkeysizeW, HkeysizeH, 'H');
    keys(keystartX2 + keyspace*6, keyline2, keysizeW, keysizeH, 'J');
    keys(keystartX2 + keyspace*7, keyline2, keysizeW, keysizeH, 'K');
    keys(keystartX2 + keyspace*8, keyline2, keysizeW, keysizeH, 'L');
    
    keys(keystartX3, keyline3, keysizeW, keysizeH, 'Z');
    keys(keystartX3 + keyspace, keyline3, keysizeW, keysizeH, 'X');
    keys(keystartX3 + keyspace*2, keyline3, keysizeW, keysizeH, 'C');
    keys(keystartX3 + keyspace*3, keyline3, VkeysizeW, VkeysizeH, 'V');
    keys(keystartX3 + keyspace*4, keyline3, keysizeW, keysizeH, 'B');
    keys(keystartX3 + keyspace*5, keyline3, NkeysizeW, NkeysizeH, 'N');
    keys(keystartX3 + keyspace*6, keyline3, keysizeW, keysizeH, 'M');

// KEY SCALE ANIMATIONS
    //"E" KEY
        EkeysizeW += keSpeed*0.25
    EkeysizeH += keSpeed*0.25
    if(EkeysizeW < 50 || EkeysizeW > 65 || EkeysizeH <40 || EkeysizeH > 65){
      keSpeed*=-1
    }
    if(eSpeed==0){
      keSpeed=0
      EkeysizeW=66
      EkeysizeH=66
    }
    //"R" KEY
     RkeysizeW += krSpeed*0.25
    RkeysizeH += krSpeed*0.25
    if(RkeysizeW < 50 || RkeysizeW > 65 || RkeysizeH <40 || RkeysizeH > 65){
      krSpeed*=-1
    }
    if(rSpeed==0){
      krSpeed=0
      RkeysizeW = 66
      RkeysizeH = 66
    }
    //"T" KEY
        TkeysizeW += ktSpeed*0.25
    TkeysizeH += ktSpeed*0.25
    if(TkeysizeW < 50 || TkeysizeW > 65 || TkeysizeH <40 || TkeysizeH > 65){
      ktSpeed*=-1
    }
    if(kSpeed==0){
      ktSpeed=0
      TkeysizeW = 66
      TkeysizeH = 66
    }
    //"U" KEY
    UkeysizeW += kuSpeed*0.25
    UkeysizeH += kuSpeed*0.25
    if(UkeysizeW < 50 || UkeysizeW > 65 || UkeysizeH <40 || UkeysizeH >65){
      kuSpeed*=-1
    }
    if(uSpeed==0){
      kuSpeed=0
      UkeysizeW = 66
      UkeysizeH = 66
    }
    //"O" KEY
    OkeysizeW += koSpeed*0.25
    OkeysizeH += koSpeed*0.25
    if(OkeysizeW < 50 || OkeysizeW > 65 || OkeysizeH <40 || OkeysizeH > 65){
      koSpeed*=-1
    }
    if(oSpeed==0){
      koSpeed=0
      OkeysizeW = 66
      OkeysizeH = 66
    }
    //"F" KEY
     F1keysizeW += kfSpeed*0.25
    F1keysizeH += kfSpeed*0.25
    if(F1keysizeW < 50 || F1keysizeW > 65 || F1keysizeH <40 || F1keysizeH >65){
      kfSpeed*=-1
    }
    if(f2Speed==0){
      kfSpeed=0
      F1keysizeW = 66
      F1keysizeH = 66
    }
    //"H" KEY
        HkeysizeW += khSpeed*0.25
    HkeysizeH += khSpeed*0.25
    if(HkeysizeW < 50 || HkeysizeW > 65 || HkeysizeH <40 || HkeysizeH >65){
      khSpeed*=-1
    }
    if(hSpeed==0){
      khSpeed=0
      HkeysizeW = 66
      HkeysizeH = 66
    }
    //"V" KEY
    VkeysizeW += kvSpeed*0.25
    VkeysizeH += kvSpeed*0.25
    if(VkeysizeW < 50 || VkeysizeW > 65 || VkeysizeH <40 || VkeysizeH >65){
      kvSpeed*=-1
    }
    if(vSpeed==0){
      kvSpeed=0
      VkeysizeW = 66
      VkeysizeH = 66
    }
    //"N" KEY
    NkeysizeW += knSpeed*0.25
    NkeysizeH += knSpeed*0.25
    if(NkeysizeW < 50 || NkeysizeW > 65 || NkeysizeH <40 || NkeysizeH >65){
      knSpeed*=-1
    }
    if(nSpeed==0){
      knSpeed=0
      NkeysizeW = 66
      NkeysizeH = 66
    }
    
    
//KEY POSITION CHANGE ANIMATIONS!!
// "T" KEY ANIMATIONS      
   if(TmovementStarted){
         keys(TXpos1, TYpos1, TkeysizeW, TkeysizeH, 'T');
      TXpos1 -= kSpeed * 14
      TYpos1 -= kSpeed * 6
    if(TXpos1 < 40|| 
      TYpos1 < 70){
    kSpeed *= 0
  }
    
          keys(TXpos2, TYpos2, TkeysizeW, TkeysizeH, 'T');
      TXpos2 -= kSpeed * 2.75
      TYpos2 -= kSpeed * 6
    if(TXpos2 < xline +sline *5|| TYpos2 < lline-50){
      kSpeed *= 0
    }
    
          keys(TXpos3, TYpos3, TkeysizeW, TkeysizeH, 'T');
      TXpos3 += kSpeed * 6.25
      TYpos3 -= kSpeed * 6

    if(TYpos3 < lline - 50){
      kSpeed *= 0
    }
  }

  
//"U"KEY ANIMATIONS
  if(UmovementStarted){
               keys(UXpos, UYpos, UkeysizeW, UkeysizeH, 'U');
      UXpos -= uSpeed * 9.625
      UYpos -= uSpeed * 3

    if(UXpos < 95|| 
      UYpos < 80){
    uSpeed *= 0
  }  
}


// "R" key animation
    if(RmovementStarted){
      keys(RXpos, RYpos, RkeysizeW, RkeysizeH, 'R');
      RXpos -= rSpeed * 5.75
      RYpos -= rSpeed * 6

    if(RXpos < 140|| RYpos < 80){
    rSpeed *= 0
  }  
}
// "N" KEY ANIMATION
  if(NmovementStarted){
      keys(NXpos, NYpos, NkeysizeW, NkeysizeH, 'N');
      NXpos -= nSpeed * 7
      NYpos -= nSpeed * 6.75
    if(NXpos < 185|| NYpos < 80){
    nSpeed *= 0
  }  
}
//"H" KEY ANIMATION
  if(HmovementStarted){
      keys(HXpos, HYpos, HkeysizeW, HkeysizeH, 'H');
      HXpos -= hSpeed * 5.75
      HYpos -= hSpeed * 9.75
    if(HXpos < 320|| HYpos < 85){
    hSpeed *= 0
  }  
}
//"E" KEY ANIMATION
    if(EmovementStarted){
      keys(EXpos, EYpos, EkeysizeW, EkeysizeH, 'E');
      EXpos -= eSpeed * -9.25
      EYpos -= eSpeed * 6
    if(EXpos > 360|| EYpos < 85){
    eSpeed *= 0
  }  
}
//"V" KEY ANIMATION
  if(VmovementStarted){
      keys(VXpos, VYpos, VkeysizeW, VkeysizeH, 'V');
      VXpos -= vSpeed * -6.625
      VYpos -= vSpeed * 9.75

    if(VXpos > 495|| VYpos < 85){
    vSpeed *= 0
  }  
}
//"O" KEY ANIMATION
    if(OmovementStarted){
      keys(OXpos, OYpos, OkeysizeW, OkeysizeH, 'O');
      OXpos -= oSpeed * 2
      OYpos -= oSpeed * 6
      OkeysizeW -= oSpeed *0.15
      OkeysizeH -= oSpeed *0.15
    if(OkeysizeW < 40 || OkeysizeH <40){
      oSpeed *=0
    }
    if(OXpos < 590|| OYpos < 80){
    oSpeed *= 0
  }  
}
//"F" KEY ANIMATION
  if(F1movementStarted){
      keys(F1Xpos, F1Ypos, F1keysizeW, F1keysizeH, 'F');
      F1Xpos -= f1Speed * -8.75
      F1Ypos -= f1Speed * 4.875

    if(F1Xpos > 635|| F1Ypos < 80){
    f1Speed *= 0
  }  
}
//"F2" KEY ANIMATION
  if(F2movementStarted){
      keys(F2Xpos, F2Ypos, F2keysizeW, F2keysizeH, 'F');
      F2Xpos -= f2Speed * -9.875
      F2Ypos -= f2Speed * 4.875

    if(F2Xpos > 680|| F2Ypos < 80){
    f2Speed *= 0
  }  
}

  break;

// SCENE 3 - now that players have learned the message "TURN THE TV OFF" it prompts this scene of animation and sound where the "tv" display turns off and the game is over
  case 3:
  image(screen3, imageW, imageH);
    fill(0)
  rect(0,0, 800, inc)
    inc += incspeed*0.85
  if(inc>250){
    incspeed = 0
  }
  rect(0,Ydec, 800, dec)
    dec -= decspeed *0.85
    Ydec -= decspeed *0.85
  if(dec < 250)
    decspeed = 0
}
  if(incspeed ==0 || decspeed == 0){
    fill(225)
    noStroke();
    rect(Xinc,240,shrinkW,shrinkH)
    ellipse(400, 250, shrinksize)
    shrinkW -= shrinkWspeed *2*200
    //shrinkH -= shrinkHspeed *10*5
    shrinksize -= shrinkspeed *10
    Xinc += shrinkWspeed *200
    if(shrinkW < 0 || Xinc == 400){
      shrinkWspeed = 0
    }
    if(shrinkH < 0){
      shrinkHspeed = 0
    }
    if (shrinksize == 0) {
      shrinkspeed = 0
    }
  }
    if (!soundPlayed && scene === 3) {
    playSound();
  }

//trigger scene 3
  if (TkeysizeW == 66 && UkeysizeW == 66 && RkeysizeW == 66 && NkeysizeW == 66 && HkeysizeW == 66 && EkeysizeW == 66 && VkeysizeW == 66 && OkeysizeW == 66 && F1keysizeW == 66 ){
    scene = 3

  }

//end draw
}
    
function keys(xPos,yPos, sizeW, sizeH, letter){
  push();
    fill(117,117,108)
    noStroke();
    rect(xPos, yPos, sizeW, sizeH, 10)
    fill(0)
    textSize(40)
    textFont('Courior New')
    textAlign(CENTER)
    text(letter, xPos +25, yPos +37)
  pop();
}
    
// trigger animations 
function keyPressed() {
  if ((key === 'T' || key === 't') && !TmovementStarted) {
    TmovementStarted = true; 
    keyclick.play();
  }
  if ((key === 'U' || key === 'u') && !UmovementStarted) {
    UmovementStarted = true; 
    keyclick.play();
  }
  if ((key === 'R' || key === 'r') && !RmovementStarted) {
    RmovementStarted = true; 
    keyclick.play();
  }
    if ((key === 'N' || key === 'n') && !NmovementStarted) {
    NmovementStarted = true; 
    keyclick.play();
  }
  if ((key === 'H' || key === 'h') && !HmovementStarted) {
    HmovementStarted = true;
    keyclick.play();
  }
  if ((key === 'E' || key === 'e') && !EmovementStarted) {
    EmovementStarted = true; 
    keyclick.play();
  }
  if ((key === 'V' || key === 'v') && !VmovementStarted) {
    VmovementStarted = true; 
    keyclick.play();
  }
   if ((key === 'O' || key === 'o') && !OmovementStarted) {
    OmovementStarted = true; 
    keyclick.play();
  }
     if ((key === 'F' || key === 'f') && !F1movementStarted) {
    F1movementStarted = true; 
    keyclick.play();
  }
       if ((key === 'F' || key === 'f') && !F2movementStarted) {
    F2movementStarted = true; 
    keyclick.play();
  }
  soundPlayed = false;

}

function mousePressed(){
  if(mouseX > rectX && mouseX < rectX + rectW && mouseY > rectY && mouseY < rectY + rectH){
    scene=1
  }
}

function playSound() {
  if (!tvoff.isPlaying()) { 
    tvoff.play(); 
    soundPlayed = true; 
  }
}

